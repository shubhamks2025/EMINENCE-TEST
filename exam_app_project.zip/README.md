# Exam App

This is a starter Exam App with Flutter + Firebase and Codemagic CI/CD setup.

## How to use

1. Upload this project to GitHub.
2. Go to [https://codemagic.io](https://codemagic.io) and connect your GitHub repo.
3. Select `codemagic.yaml` workflow and start build.
4. You will get `app-release.apk` and `app-release.aab` after successful build.
5. Use `.aab` file to upload on Google Play Store.

